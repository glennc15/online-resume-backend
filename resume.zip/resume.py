import json



def resume_handler(event, context):
    status_code = 200

    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
    }

    body = {
        'message': "Hello World!",
        'event': event,
        # 'context': context
    }

    results = {
        "status": status_code,
        "headers": headers,
        "body": body,
    }

    return json.dumps(results)
